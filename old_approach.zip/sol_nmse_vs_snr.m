% SOLUTION FILE for NMSE vs. SNR
% exp_nmse_vs_snr.m
% Experiment: NMSE vs SNR for M in {80, 120}. Produces a plot.
clear; close all; clc;

params0 = channel_params();

if ~exist(params0.log_dir,'dir'); mkdir(params0.log_dir); end
logfile = fullfile(params0.log_dir, sprintf('exp_nmse_vs_snr_%s.log', char(datetime('now','Format','yyyyMMdd_HHmmss'))));
diary(logfile); diary on;

fprintf('== EXP: NMSE vs SNR ==\n');

M_list = [80 120];
SNRdB_list = -15:5:10;
nmse_curves = zeros(numel(M_list), numel(SNRdB_list));

for iM = 1:numel(M_list)
    params = channel_params("M", M_list(iM), ...
                            "random_seed", 100+iM, ...
                            "mock_reconstruction", false, ...   % <--- use SW-OMP
                            "verbose", true, ...
                            "debug_dump", false);
    fprintf('--- M=%d ---\n', params.M);
    for iS = 1:numel(SNRdB_list)
        snrdb = SNRdB_list(iS);
        acc = 0;
        for t = 1:params.Nmc
            seed_rng(params.random_seed + 1000*iM + 100*iS + t);  % NEW: unique per trial
            [H,~] = gen_channel(params);
            [W_RF,W_BB,F_RF,F_BB] = build_training(params);
            [y, A, meta] = vectorize_measurements(H, W_RF,W_BB,F_RF,F_BB, params, snrdb);
            [rec,~] = swomp(y, A, meta, params);
            acc = acc + nmse(H, rec.H_hat, params);
        end

        nmse_curves(iM,iS) = acc/params.Nmc;
        fprintf('M=%d | SNR=%+3.0f dB -> NMSE=%.3e\n', params.M, snrdb, nmse_curves(iM,iS));
    end
end

nmse_db = 10*log10(max(nmse_curves, realmin));   % avoid log of 0

figure; hold on; grid on;
plot(SNRdB_list, nmse_db(1,:), '-o', 'DisplayName','M=80');
plot(SNRdB_list, nmse_db(2,:), '-s', 'DisplayName','M=120');
xlabel('SNR (dB)'); ylabel('NMSE (dB)');
title('NMSE (dB) vs SNR (on-grid angles)');
ylim([-35 5]);      % rough paper-like range; adjust if needed
legend('Location','southwest');

outdir = fullfile(pwd,'fig'); if ~exist(outdir,'dir'); mkdir(outdir); end
saveas(gcf, fullfile(outdir,'nmse_vs_snr_M80_M120.png'));
save(fullfile(outdir,'nmse_vs_snr_data.mat'), 'SNRdB_list','M_list','nmse_curves');
fprintf('Logs written to: %s\n', logfile);
diary off;