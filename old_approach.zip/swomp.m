% swomp.m
% Simultaneous Weighted OMP (skeleton).
% Inputs:
%   y, A, meta, params
% Outputs:
%   rec : struct with fields
%       .H_hat  [Nr x Nt x K]  (reconstructed channel)
%       .x_hat  (sparse coeffs if using dictionary; optional)
%       .support (selected atom indices; optional)
%   info: struct with diagnostics

function [rec, info] = swomp(y, ~, meta, params)
% Fast SW-OMP with whitening, full vectorization across K, and optional GPU/single.
% Required fields in params (same as before) plus optional:
%   params.use_gpu   = true/false
%   params.use_single= true/false
%   params.verbose   = true/false

%% -------- settings & dims
Nr=meta.dims(1); Nt=meta.dims(2); K=meta.dims(3); Ns=meta.dims(4); M=meta.dims(5);
W_RF=meta.W_RF; W_BB=meta.W_BB; F_RF=meta.F_RF; F_BB=meta.F_BB;

Ng_rx=params.Ng_rx; Ng_tx=params.Ng_tx; Ng_tau=params.Ng_tau;
fs=params.fs; BW=params.BW;
maxIters = min(getdef(params,'max_iters',params.L), Ng_tau*Ng_rx*Ng_tx);
stop_tol = getdef(params,'stop_tol',1e-3);
use_gpu   = isfield(params,'use_gpu')    && params.use_gpu    && gpuDeviceCount>0;
use_single= isfield(params,'use_single') && params.use_single;
verbose   = isfield(params,'verbose')    && params.verbose;

%% -------- steering on angle grids (vectorized)
txg = asin(linspace(-1,1,Ng_tx)); rxg = asin(linspace(-1,1,Ng_rx));
nrx = (0:Nr-1).'; ntx = (0:Nt-1).';
A_rx = exp(1j*pi * (nrx) * sin(rxg));                  % [Nr x Ng_rx]
A_tx = exp(1j*pi * (ntx) * sin(txg));                  % [Nt x Ng_tx]
A_ang = kron(conj(A_tx), A_rx);                        % [Nr*Nt x Qang]
Qang  = Ng_rx*Ng_tx;

%% -------- training operator & whitening blocks (fast sqrt via chol)
blk = Ns*Ns; Lm = M*blk;
T_stack = zeros(Lm, Nr*Nt);
Wcells  = cell(M,1);
rowrng  = @(m) ((m-1)*blk + (1:blk));

for m=1:M
    Wm = W_RF(:,:,m)*W_BB(:,:,m);      % [Nr x Ns]
    Fm = F_RF(:,:,m)*F_BB(:,:,m);      % [Nt x Ns]
    T_stack(rowrng(m),:) = kron(Fm.', Wm');     % [Ns^2 x Nr*Nt]

    % Whitening for colored noise after combining: invsqrt(Wm'Wm) via chol
    G = (Wm'*Wm); G = (G+G')/2;                     % hermitian guard
    L = chol(G,'lower'); Gi = (L') \ eye(Ns);       % invsqrt(G) = inv(L')
    Wcells{m} = kron(eye(Ns), Gi);                  % [Ns^2 x Ns^2]
end
Wblk = blkdiag(Wcells{:});                          % [Lm x Lm]

%% -------- build whitened operator once
Gop = Wblk * T_stack;                               % [Lm x Nr*Nt]
B   = Gop * A_ang;                                  % [Lm x Qang]

%% -------- frequency/delay focusing matrix (constant)
taug = (0:Ng_tau-1).' / fs;                          % [Ng_tau x 1]
f    = linspace(-BW/2, BW/2, K).';                   % [K x 1]
D    = exp(-1j*2*pi * (taug * f.'));               % [Ng_tau x K]
D_H  = conj(D).';                                    % [K x Ng_tau]

%% -------- precision / device
castf = @(x) x;
if use_single, castf = @(x) single(x); end
B    = castf(B); D_H = castf(D_H); A_ang = castf(A_ang);
y    = castf(y);  Wblk = castf(Wblk);

if use_gpu
    B = gpuArray(B); D_H = gpuArray(D_H);
    y = gpuArray(y); Wblk = gpuArray(Wblk);
end

%% -------- whiten y and reshape once
y_wh_mat = reshape(y, Lm, K);                        % stacked by k
y_wh_mat = Wblk * y_wh_mat;                          % whiten all K in one shot
y_stack   = y_wh_mat(:);                             % [K*Lm x 1]
R         = y_wh_mat;                                % residual matrix [Lm x K]

%% -------- precompute norms (column energy of B), keep as column vector
bnrm_sqrt = sqrt(sum(abs(B).^2,1)).';                % [Qang x 1]

%% -------- greedy iterations
S_q = zeros(maxIters,1,'uint32'); S_l = zeros(maxIters,1,'uint32');
xS  = zeros(maxIters,1,class(B));
res_hist = zeros(maxIters+1,1,'like',castf(0)); res_hist(1) = norm(y_stack)^2;

for t=1:maxIters
    % All correlations across K at once:
    %   S = B' * R  -> [Qang x K]
    S = B' * R;

    % Coherent delay focusing across K (small GEMM):
    C = S * D_H;                                     % [Qang x Ng_tau]

    % Normalize by dictionary col energy and pick best (vectorized)
    Cn = abs(C) ./ bnrm_sqrt;                        % implicit broadcast
    [~, idx_lin] = max(Cn(:));
    l = uint32(ceil(double(idx_lin)/double(Qang)));
    q = uint32(idx_lin - (double(l)-1)*double(Qang));
    S_q(t)=q; S_l(t)=l;

    % --- Build/update AS (K*Lm x t) using Kronecker columns
    v = B(:,q);                                      % whitened spatial column [Lm x 1]
    e = exp(-1j*2*pi*f*taug(l));                     % [K x 1]
    col_t = kron(e, v);                              % [K*Lm x 1]

    if t==1
        AS = col_t;
    else
        AS(:,t) = col_t;                             %#ok<AGROW>
    end

    % Solve LS (t tiny => very cheap)
    xS(1:t) = AS(:,1:t) \ y_stack;

    % Update residuals in both vector and matrix forms
    r_stack = y_stack - AS(:,1:t)*xS(1:t);
    R = reshape(r_stack, Lm, K);                     % keep R for next corr
    res_hist(t+1) = norm(r_stack)^2;

    if res_hist(t)>0
        imp = (res_hist(t)-res_hist(t+1)) / res_hist(t);
        if imp < stop_tol, break; end
    end
end

T = find(S_q==0,1) - 1; if isempty(T), T = maxIters; end
S_q = S_q(1:T); S_l = S_l(1:T); xS = xS(1:T);

%% -------- reconstruct H_hat on CPU for portability
if use_gpu
    S_q = gather(S_q); S_l = gather(S_l); xS = gather(xS);
    A_ang = gather(A_ang); f = gather(f); taug = gather(taug);
end

H_hat = zeros(Nr,Nt,K);
for k=1:K
    hvec = zeros(Nr*Nt,1,class(A_ang));
    ek = exp(-1j*2*pi*f(k)*taug(S_l));
    for j=1:T
        hvec = hvec + A_ang(:,S_q(j)) * (ek(j) * xS(j));
    end
    H_hat(:,:,k) = reshape(hvec, Nr, Nt);
end

rec.H_hat   = H_hat;
rec.x_hat   = xS;
rec.support = [double(S_q) double(S_l)];
info.residual_hist = double(gather_if_needed(res_hist(1:T+1)));
info.Qang = Qang; info.maxIters=maxIters; info.stop_tol=stop_tol;

if verbose
    fprintf('[SW-OMP fast] T=%d, final resid=%.3e\n',T,info.residual_hist(end));
end
end

function v = getdef(s, field, dflt)
    if isfield(s,field) && ~isempty(s.(field)), v = s.(field); else, v = dflt; end
end
function x = gather_if_needed(x)
    if isa(x,'gpuArray'), x=gather(x); end
end
